/**
 * Módulo de Autenticación - ObraMetric Studio
 * Utiliza localStorage para simular una base de datos.
 */
(function () {
    'use strict';
    
    const USERS_KEY = 'obrametric_users_v1';
    const SESSION_KEY = 'obrametric_session_v1';

    // --- Utilidades de Storage ---
    const readJSON = (key, fallback) => {
        try {
            const value = JSON.parse(localStorage.getItem(key));
            return value ?? fallback;
        } catch { return fallback; }
    };
    const saveJSON = (key, data) => localStorage.setItem(key, JSON.stringify(data));

    // --- Gestión de Usuarios ---
    const getUsers = () => {
        const users = readJSON(USERS_KEY, []);
        return Array.isArray(users) ? users : [];
    };

    const getSession = () => {
        const session = readJSON(SESSION_KEY, null);
        if (!session || !session.id) return null;
        const user = getUsers().find((u) => u.id === session.id);
        return user ? { id: user.id, name: user.name, email: user.email } : null;
    };

    const logout = () => {
        localStorage.removeItem(SESSION_KEY);
        window.location.replace('index.html');
    };

    // --- Criptografía Básica ---
    // Función asíncrona para hashear contraseñas.
    async function digest(password) {
        if (window.crypto && window.crypto.subtle) {
            const buf = await window.crypto.subtle.digest('SHA-256', new TextEncoder().encode(password));
            return 'sha256:' + [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
        }
        // Fallback para navegadores sin crypto.subtle (ej. file://)
        let h1 = 0xdeadbeef, h2 = 0x41c6ce57;
        for (let i = 0; i < password.length; i++) {
            const c = password.charCodeAt(i);
            h1 = Math.imul(h1 ^ c, 2654435761);
            h2 = Math.imul(h2 ^ c, 1597334677);
        }
        h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
        h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
        return 'demo:' + (h2 >>> 0).toString(16).padStart(8, '0') + (h1 >>> 0).toString(16).padStart(8, '0');
    }

    // Exportar API pública para app.js
    window.ObraAuth = { getSession, logout };

    // --- Lógica de la Interfaz (Solo si estamos en index.html) ---
    const isDashboard = /dashboard\.html$/i.test(location.pathname);
    if (isDashboard && !getSession()) { 
        location.replace('index.html'); 
        return; 
    }
    
    const authForm = document.getElementById('auth-form');
    if (!authForm) return;
    if (getSession()) { 
        location.replace('dashboard.html'); 
        return; 
    }

    // UI Elements
    const $ = (id) => document.getElementById(id);
    const msgBox = $('auth-message');
    let isRegisterMode = false;

    function setMode(registering) {
        isRegisterMode = registering;
        $('name-field').classList.toggle('hidden', !registering);
        $('confirm-field').classList.toggle('hidden', !registering);
        $('login-tab').classList.toggle('active', !registering);
        $('register-tab').classList.toggle('active', registering);
        $('login-tab').setAttribute('aria-pressed', String(!registering));
        $('register-tab').setAttribute('aria-pressed', String(registering));
        
        $('auth-heading').textContent = registering ? 'Crea tu cuenta' : 'Accede a tu espacio';
        $('auth-subtitle').textContent = registering ? 'Regístrate para guardar tus estimaciones.' : 'Ingresa tus datos para continuar con tus proyectos.';
        $('submit-auth').innerHTML = (registering ? 'Crear cuenta' : 'Iniciar sesión') + ' <span aria-hidden="true">→</span>';
        
        $('password').autocomplete = registering ? 'new-password' : 'current-password';
        msgBox.textContent = '';
    }

    $('login-tab').addEventListener('click', () => setMode(false));
    $('register-tab').addEventListener('click', () => setMode(true));

    authForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        msgBox.textContent = '';
        
        const email = $('email').value.trim().toLowerCase();
        const password = $('password').value;

        // Validaciones
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { 
            msgBox.textContent = 'Ingresa un correo electrónico válido.'; return; 
        }
        if (password.length < 8) { 
            msgBox.textContent = 'La contraseña debe tener al menos 8 caracteres.'; return; 
        }

        const users = getUsers();

        if (isRegisterMode) {
            const name = $('full-name').value.trim().replace(/\s+/g, ' ');
            if (name.length < 2) { 
                msgBox.textContent = 'Escribe un nombre de al menos 2 caracteres.'; return; 
            }
            if (password !== $('confirm-password').value) { 
                msgBox.textContent = 'Las contraseñas no coinciden.'; return; 
            }
            if (users.some((u) => u.email === email)) { 
                msgBox.textContent = 'Ya existe una cuenta con ese correo.'; return; 
            }
            
            const newUser = { 
                id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()), 
                name, email, 
                passwordHash: await digest(password) 
            };
            
            try { 
                saveJSON(USERS_KEY, [...users, newUser]); 
                saveJSON(SESSION_KEY, { id: newUser.id }); 
                location.replace('dashboard.html'); 
            } catch { 
                msgBox.textContent = 'Error al guardar. Revisa el almacenamiento de tu navegador.'; 
            }
            return;
        }

        // Login
        const user = users.find((u) => u.email === email);
        if (!user || user.passwordHash !== await digest(password)) { 
            msgBox.textContent = 'Correo o contraseña incorrectos.'; return; 
        }
        
        saveJSON(SESSION_KEY, { id: user.id });
        location.replace('dashboard.html');
    });
})();